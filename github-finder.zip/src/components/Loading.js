import React, { Component } from 'react'

export class Loading extends Component {
  render() {
    return (<div class="d-flex justify-content-center"><div class="d-flex align-items-center">
        <div className="spinner-border text-primary" role="status">
        <span className="sr-only" style={{fontSize:'5px;'}}>Loading...</span></div></div>
      </div>
    )
  }
}

export default Loading